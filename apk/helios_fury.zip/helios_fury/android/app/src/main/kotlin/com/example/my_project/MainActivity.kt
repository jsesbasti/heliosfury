package com.mycompany.heliosfury

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
