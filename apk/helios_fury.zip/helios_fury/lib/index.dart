// Export pages
export '/home/home_widget.dart' show HomeWidget;
export '/simulation/simulation_widget.dart' show SimulationWidget;
export '/history/history_widget.dart' show HistoryWidget;
export '/glossary/glossary_widget.dart' show GlossaryWidget;
export '/game/game_widget.dart' show GameWidget;
